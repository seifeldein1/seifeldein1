from django.contrib import admin
from .models import RentalBreakdown

# Register your models here.
admin.site.register(RentalBreakdown)
